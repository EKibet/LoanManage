from django.apps import AppConfig


class LoansappConfig(AppConfig):
    name = 'LoansApp'
